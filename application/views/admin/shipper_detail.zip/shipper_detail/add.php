<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>
<?php init_head(); ?>
<div id="wrapper">
    <div class="content">
        <div class="row">
            <div class="col-md-12">
                <div class="panel-body _buttons">
                    <a href="<?php echo admin_url('shipper_detail'); ?>" class="pull-right btn btn-info display-block"><?php echo _l('All Shippers'); ?></a>
                    <div class="clearfix"></div>
                    <h3><?php echo _l('Shipper Information'); ?></h3>
                    <hr class="hr-panel-heading" />
                    <div class="row" id="contract_summary">

                        <div class="col-sm-12 col-md-8">
                          <div class="col-sm-12 col-md-4">
                            <div class="row">
                              <div class="col-sm-12 col-md-12">
                                  <label><?php echo _l('Shipper Code'); ?><span class="danger">*</span></label>
                                  <br/>
                                  <input type="text" name="code" value="">
                              </div>
                            </div>
                          </div>
                          <div class="col-sm-12 col-md-4">
                            <div class="row">
                              <div class="col-sm-12 col-md-12">
                                  <label><?php echo _l('Shipper Code'); ?><span class="danger">*</span></label>
                                  <br/>
                                  <input type="text" name="code" value="">
                              </div>
                            </div>
                          </div>
                          <div class="col-sm-12 col-md-4">
                            <div class="row">
                              <div class="col-sm-12 col-md-12">
                                  <label><?php echo _l('Shipper Code'); ?><span class="danger">*</span></label>
                                  <br/>
                                  <input type="text" name="code" value="">
                              </div>
                            </div>
                          </div>
                        </div>
                        <div class="col-sm-12 col-md-4">

                        </div>
             


                    </div>
               </div>
           </div>
       </div>
   </div>
   <?php init_tail(); ?>
   <script>
    $(function(){
   
      
    });
</script>
</body>
</html>
